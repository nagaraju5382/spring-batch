package com.cgi.org.servies;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class NumberInformationService {
	
	
	public   String getNumberInfromatiom(int number) {
		
		String mas=null;
		if (number % 3 == 0 && number % 5 == 0 ) {
			mas="fizzbuzz";
			
		} else if (number % 5 == 0 ) {
			mas="buzz";
			
		} else if (number % 3 == 0) {
			mas="fizz";
			
		}
		return mas.toString();
	}
	
	
	public   List<Integer> getAllNumbers(int number) {
		List<Integer> listofNum= new ArrayList<>();
		for (int i = 1; i <= number; i++) {
			listofNum.add(i);
			
		}
		return listofNum;
	}
	
	
	public String getDate()
	{
		
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("EEE");
		return formatter.format(cal.getTime());
		
		
		
	}
	
	public boolean validateNumber(int number){	
		boolean result;
		if (0 < number && number < 1001) {
			result=true;	
			}		
		else {
			result= false;
		}
		return result;
	}
	

	}
	


