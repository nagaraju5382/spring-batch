
package com.cgi.org.servies.test;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cgi.org.controller.NumberInformationController;
import com.cgi.org.servies.NumberInformationService;


@RunWith(SpringJUnit4ClassRunner.class)
public class TestActivityController {
    
	@InjectMocks
	private NumberInformationController numberInformationController;

	 MockMvc mockMvc;
	 @Mock
	 NumberInformationService numberInformationService;
	

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(numberInformationController).build();
	}

 
    @Test
    public void testInitialDisplay() throws Exception {
        User user = new User("bill","abc123", AuthorityUtils.createAuthorityList("ROLE_PATRON"));
        TestingAuthenticationToken testingAuthenticationToken = new TestingAuthenticationToken(user,"abc123");
        SecurityContextHolder.getContext().setAuthentication(testingAuthenticationToken);
       when(numberInformationService.getAllNumbers(1)).thenReturn(new ArrayList<Integer>());
        mockMvc.perform(post("/userinput/3"))
                //.principal(testingAuthenticationToken))
        		.andExpect(status().isOk());
                
    }
}


