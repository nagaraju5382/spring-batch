package com.cgi.org.controller.test;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cgi.org.controller.NumberInformationController;
import com.cgi.org.servies.NumberInformationService;


@RunWith(SpringJUnit4ClassRunner.class)
public class NumberInformationControllerTest  {

	
	@InjectMocks
	private NumberInformationController numberInformationController;

	 MockMvc mockMvc;
	
	@Mock
	NumberInformationService numberInformationService;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(numberInformationController).build();
	}

	@Test
	public void testgetNumberAllInfoSucess() throws Exception {
		List<Integer> list=new ArrayList<Integer>();
		for(int i=0;i<=10;i++){
			list.add(i);
		}
		
		when(numberInformationService.getAllNumbers(1)).thenReturn(new ArrayList<Integer>());
		mockMvc.perform(
				post("/fatch/3")
				.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());
	}
	
	@Test(expected = Error.class)
	public void testgetNumberAllInfail() throws Exception {
		List<Integer> list=new ArrayList<Integer>();
		for(int i=0;i<=10;i++){
			list.add(i);
		}		
		when(numberInformationService.getAllNumbers(1)).thenThrow(new RuntimeException("testException"));
		mockMvc.perform(
				post("/fatch/3")
				.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().is5xxServerError());
	}
	
	
	
	@Test
	public void testgetNumberInfoSucess() throws Exception {
		//String name="fizz";
		when(numberInformationService.getNumberInfromatiom(3)).thenReturn("fizz"); 
		mockMvc.perform(
				post("/userinput/3")
				.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());
	}
	
	@Test(expected = Exception.class)
	public void testgetNumberInfail() throws Exception {
		when(numberInformationService.getNumberInfromatiom(3)).thenThrow(new RuntimeException("testException"));
		mockMvc.perform(
				post("/userinput/3")
				.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().is5xxServerError());
	}
	
	
	
}






    /*  @Test 
        public void testgetNumberInfoSucess() throws Exception { 
                
                Modeltest mv = new Modeltest(); 
                mv.setA("fizz"); 
                
                //String name="fizz"; 
                when(numberInformationService.getNumberInfromatiom(3).thenReturn(name)); 
                mockMvc.perform( 
                                post("/userinput/3") 
                                .contentType(MediaType.APPLICATION_JSON)) 
                .andExpect(status().isOk()); 
                
                assertTrue(numberInformationService.getNumberInfromatiom(3).equals(mv.getA())); 
                
        } */





